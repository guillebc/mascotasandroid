# CourseraMascotasFAvoritas
Tarea Semana 3 de Desarrollando Aplicaciones en Android.
Se han agregado los elementos solicitados y que se aprecian en las imágenes de referencia, aunque algunos no contienen comportamiento alguno,
como el Floating Action Button.
